package com.aui.sms

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.BlockedNumberContract
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.telephony.SubscriptionManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.core.view.WindowCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/** Native functions exposed to the web UI as window.AuiBridge. */
@Suppress("DEPRECATION")
class Bridge(private val act: Activity) {
    var web: WebView? = null
    private val ctx: Context = act.applicationContext
    private fun has(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun ui(f: () -> Unit) = act.runOnUiThread(f)
    private fun launch(i: Intent) = ui { try { act.startActivity(i) } catch (e: Exception) {} }
    private fun js(s: String) = act.runOnUiThread { web?.evaluateJavascript(s, null) }
    private fun clean(n: String) = n.filter { it.isDigit() || it == '+' || it == '*' || it == '#' }

    // ---- messages ----
    @JavascriptInterface fun getConversations(limit: Int): String = if (has(Manifest.permission.READ_SMS)) SmsOps.conversations(ctx, limit) else "[]"
    @JavascriptInterface fun getMessages(thread: String, limit: Int): String = if (has(Manifest.permission.READ_SMS)) SmsOps.messages(ctx, thread, limit) else "[]"
    @JavascriptInterface fun getTagged(tag: String, limit: Int): String = if (has(Manifest.permission.READ_SMS)) SmsOps.tagged(ctx, tag, limit) else "[]"
    @JavascriptInterface fun search(q: String): String = if (has(Manifest.permission.READ_SMS)) SmsOps.search(ctx, q) else "[]"
    @JavascriptInterface fun markRead(thread: String) { SmsOps.markRead(ctx, thread) }
    @JavascriptInterface fun deleteThread(thread: String) { SmsOps.deleteThread(ctx, thread) }
    @JavascriptInterface fun deleteMessage(id: String) { SmsOps.deleteMessage(ctx, id) }

    @JavascriptInterface fun send(addrsJson: String, body: String, sub: Int): String {
        if (!has(Manifest.permission.SEND_SMS)) { ui { act.requestPermissions(arrayOf(Manifest.permission.SEND_SMS), 5) }; return "{\"ok\":false}" }
        return try {
            val a = JSONArray(addrsJson)
            for (i in 0 until a.length()) SmsOps.send(ctx, a.getString(i), body, sub)
            ctx.getSharedPreferences("sms-prefs", Context.MODE_PRIVATE).edit().putInt("lastSub", sub).apply()
            "{\"ok\":true}"
        } catch (e: Exception) { CrashLog.save(ctx, e); "{\"ok\":false}" }
    }

    // ---- scheduling / prefs ----
    @JavascriptInterface fun setScheduled(json: String) { Scheduler.save(ctx, json) }
    @JavascriptInterface fun getScheduled(): String = Scheduler.raw(ctx)
    @JavascriptInterface fun setPrefs(json: String) {
        try {
            val o = JSONObject(json)
            ctx.getSharedPreferences("sms-prefs", Context.MODE_PRIVATE).edit()
                .putBoolean("snd", o.optInt("snd", 1) == 1).putBoolean("prev", o.optInt("prev", 1) == 1).putBoolean("otp", o.optInt("otp", 1) == 1).apply()
        } catch (e: Exception) {}
    }

    // ---- SIMs and contacts ----
    @JavascriptInterface fun getSims(): String {
        val out = JSONArray()
        try {
            val list = ctx.getSystemService(SubscriptionManager::class.java).activeSubscriptionInfoList ?: emptyList()
            for (s in list) out.put(JSONObject().put("sub", s.subscriptionId).put("slot", s.simSlotIndex + 1)
                .put("name", (s.carrierName ?: s.displayName ?: "").toString()).put("num", s.number ?: ""))
        } catch (e: SecurityException) {}
        return out.toString()
    }

    @JavascriptInterface fun getContacts(): String {
        if (!has(Manifest.permission.READ_CONTACTS)) return "[]"
        val map = LinkedHashMap<String, JSONObject>()
        ctx.contentResolver.query(Phone.CONTENT_URI, arrayOf(Phone.CONTACT_ID, Phone.DISPLAY_NAME, Phone.NUMBER), null, null,
            "${Phone.DISPLAY_NAME} COLLATE NOCASE ASC")?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val num = c.getString(2) ?: continue
                val o = map.getOrPut(id) { JSONObject().put("id", id).put("name", c.getString(1) ?: "").put("phone", num).put("ph", JSONArray()) }
                val ph = o.getJSONArray("ph")
                val k = num.filter { it.isDigit() }.takeLast(10)
                if ((0 until ph.length()).none { ph.getString(it).filter { d -> d.isDigit() }.takeLast(10) == k }) ph.put(num)
            }
        }
        return JSONArray(map.values).toString()
    }

    @JavascriptInterface fun newContact(addr: String) = launch(Intent(ContactsContract.Intents.Insert.ACTION).apply {
        type = ContactsContract.RawContacts.CONTENT_TYPE; putExtra(ContactsContract.Intents.Insert.PHONE, addr) })

    @JavascriptInterface fun setBlocked(n: String, on: Boolean) {
        try {
            if (on) ctx.contentResolver.insert(BlockedNumberContract.BlockedNumbers.CONTENT_URI,
                android.content.ContentValues().apply { put(BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER, n) })
            else BlockedNumberContract.unblock(ctx, n)
        } catch (e: Exception) {}
    }

    // ---- misc ----
    @JavascriptInterface fun call(a: String) = launch(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", clean(a), null)))
    @JavascriptInterface fun copy(t: String) = ui { (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("aui", t)) }
    @JavascriptInterface fun openUrl(u: String) = launch(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
    @JavascriptInterface fun shareText(t: String) = launch(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t), null))
    @JavascriptInterface fun isDefault(): Boolean = SmsOps.isDefault(ctx)
    @JavascriptInterface fun requestDefault() = ui { (act as? MainActivity)?.askRole(true) }
    @JavascriptInterface fun openAppSettings() = ui { (act as? MainActivity)?.openAppSettings() }
    @JavascriptInterface fun showDiagnostics() = ui { (act as? MainActivity)?.showDiag() }
    @JavascriptInterface fun setBars(light: Boolean) = ui {
        val c = if (light) 0xFFF6F0E4.toInt() else Color.BLACK
        act.window.statusBarColor = c; act.window.navigationBarColor = c
        WindowCompat.getInsetsController(act.window, act.window.decorView).apply { isAppearanceLightStatusBars = light; isAppearanceLightNavigationBars = light }
    }

    // ---- location (offline GPS / last known) ----
    private fun deliverLoc(l: Location) = js("window.onLocation&&window.onLocation({lat:${l.latitude},lon:${l.longitude}})")
    @JavascriptInterface fun getLocation() = ui {
        if (!has(Manifest.permission.ACCESS_FINE_LOCATION) && !has(Manifest.permission.ACCESS_COARSE_LOCATION)) {
            act.requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 11)
            js("window.onLocation&&window.onLocation(null)"); return@ui
        }
        val lm = ctx.getSystemService(LocationManager::class.java)
        var best: Location? = null
        for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)) {
            try { val l = lm.getLastKnownLocation(p); if (l != null && (best == null || l.time > best!!.time)) best = l } catch (e: SecurityException) {}
        }
        val b = best
        if (b != null && System.currentTimeMillis() - b.time < 10 * 60 * 1000) { deliverLoc(b); return@ui }
        if (Build.VERSION.SDK_INT >= 30) {
            val prov = if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) LocationManager.GPS_PROVIDER
                else if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) LocationManager.NETWORK_PROVIDER else null
            if (prov != null) {
                try {
                    lm.getCurrentLocation(prov, null, ctx.mainExecutor) { l -> if (l != null) deliverLoc(l) else if (b != null) deliverLoc(b) else js("window.onLocation&&window.onLocation(null)") }
                    return@ui
                } catch (e: SecurityException) {}
            }
        }
        if (b != null) deliverLoc(b) else js("window.onLocation&&window.onLocation(null)")
    }

    // ---- voice: speech recognition (assistant + dictation) and text-to-speech ----
    private var rec: SpeechRecognizer? = null
    private var recMode = ""
    private var recTag = "en-US"
    private var want = false
    private val hh = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private fun deliver(t: String, fin: Boolean) = js("window.onSpeech&&window.onSpeech({mode:'$recMode',final:$fin,text:${JSONObject.quote(t)}})")

    @JavascriptInterface fun listen(tag: String, mode: String) = ui {
        if (!has(Manifest.permission.RECORD_AUDIO)) {
            act.requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 9)
            js("window.onSpeechError&&window.onSpeechError('perm')"); return@ui
        }
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) { js("window.onSpeechError&&window.onSpeechError('na')"); return@ui }
        stopRecOnly(); recMode = mode; recTag = tag; want = true; startRec()
    }
    @JavascriptInterface fun stopListen() = ui { want = false; stopRecOnly() }
    private fun stopRecOnly() { try { rec?.stopListening(); rec?.destroy() } catch (e: Exception) {}; rec = null }
    private fun restart() { stopRecOnly(); hh.postDelayed({ if (want) startRec() }, 250) }
    private fun startRec() {
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, b: Bundle?) {}
            override fun onPartialResults(b: Bundle?) { b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { deliver(it, false) } }
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                if (t.isNotEmpty()) deliver(t, true)
                if (recMode == "note" && want) hh.post { restart() } else want = false
            }
            override fun onError(e: Int) {
                if (recMode == "note" && want && (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)) hh.post { restart() }
                else { want = false; js("window.onSpeechError&&window.onSpeechError('$e')") }
            }
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, recTag)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName))
    }
    @JavascriptInterface fun speak(text: String, tag: String) = ui {
        val go: () -> Unit = { tts?.language = Locale.forLanguageTag(tag); tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "va") }
        if (tts == null) tts = TextToSpeech(ctx) { ttsReady = it == TextToSpeech.SUCCESS; if (ttsReady) go() } else if (ttsReady) go()
    }
    fun release() { want = false; stopRecOnly(); try { tts?.shutdown() } catch (e: Exception) {}; tts = null }
}
