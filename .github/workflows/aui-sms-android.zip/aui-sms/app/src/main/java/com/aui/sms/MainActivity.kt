package com.aui.sms

import android.Manifest
import android.app.AlertDialog
import android.app.NotificationManager
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.provider.Telephony
import android.webkit.WebView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var bridge: Bridge
    private var loaded = false
    private val pending = ArrayList<String>()
    private val prefs by lazy { getPreferences(MODE_PRIVATE) }
    private val obs = object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) { js("window.refreshSms&&window.refreshSms()") }
    }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        js("window.onResumeNative&&window.onResumeNative()")
        val blocked = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED && !shouldShowRequestPermissionRationale(it) }
        if (blocked.isNotEmpty()) {
            AlertDialog.Builder(this).setTitle("Permissions needed")
                .setMessage("Messaging won't work until you allow SMS, Contacts and Phone access in Settings.")
                .setPositiveButton("Open settings") { _, _ -> openAppSettings() }
                .setNegativeButton("Later") { _, _ -> afterPerms() }.show()
        } else afterPerms()
    }
    private val roleLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        js("window.onResumeNative&&window.onResumeNative()")
    }

    private val perms: List<String> get() = buildList {
        add(Manifest.permission.READ_SMS); add(Manifest.permission.SEND_SMS); add(Manifest.permission.RECEIVE_SMS)
        add(Manifest.permission.READ_CONTACTS); add(Manifest.permission.READ_PHONE_STATE); add(Manifest.permission.READ_PHONE_NUMBERS)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        bridge = Bridge(this)
        Web.setup(web, bridge) {
            loaded = true
            pending.forEach { web.evaluateJavascript(it, null) }
            pending.clear()
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.nativeBack&&window.nativeBack())?1:0") { if (it != "1") finish() }
            }
        })
        handle(intent)
        startFlow()
        if (CrashLog.unseen(this)) web.postDelayed({ showDiag(); CrashLog.seen(this) }, 900)
    }

    override fun onStart() { super.onStart(); contentResolver.registerContentObserver(Telephony.Sms.CONTENT_URI, true, obs) }
    override fun onStop() { contentResolver.unregisterContentObserver(obs); super.onStop() }
    override fun onResume() { super.onResume(); js("window.onResumeNative&&window.onResumeNative()") }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); handle(intent) }
    override fun onDestroy() { if (::bridge.isInitialized) bridge.release(); super.onDestroy() }

    private fun js(s: String) { if (loaded) web.evaluateJavascript(s, null) }
    private fun run(s: String) { if (loaded) web.evaluateJavascript(s, null) else pending.add(s) }

    private fun handle(i: Intent?) {
        if (i == null) return
        i.getStringExtra("thread")?.let { run("window.openThread&&window.openThread(${JSONObject.quote(it)})"); i.removeExtra("thread"); return }
        when (i.action) {
            Intent.ACTION_SENDTO, Intent.ACTION_VIEW -> {
                val d = i.data ?: return
                if (d.scheme !in listOf("sms", "smsto", "mms", "mmsto")) return
                val ssp = d.schemeSpecificPart ?: ""
                val addr = Uri.decode(ssp.substringBefore('?'))
                var body = i.getStringExtra("sms_body") ?: i.getStringExtra(Intent.EXTRA_TEXT) ?: ""
                if (body.isEmpty() && ssp.contains("body=")) body = Uri.decode(ssp.substringAfter("body=").substringBefore('&'))
                run("window.composeTo&&window.composeTo(${JSONObject.quote(addr)},${JSONObject.quote(body)})")
            }
            Intent.ACTION_SEND -> i.getStringExtra(Intent.EXTRA_TEXT)?.let { run("window.shareIn&&window.shareIn(${JSONObject.quote(it)})") }
        }
    }

    // ---- first run: permissions -> default SMS app ----
    private fun startFlow() {
        if (prefs.getBoolean("onb", false)) { requestPerms(); return }
        AlertDialog.Builder(this).setTitle("Set up AUI SMS").setCancelable(false)
            .setMessage("To send and receive messages, AUI SMS needs:\n\n• SMS – read, send and receive messages\n• Contacts – names instead of numbers\n• Phone – SIM information for dual-SIM phones\n• Notifications – new message alerts\n\nThen you'll be asked to make it your default SMS app. Everything stays on your phone; the app has no internet access.")
            .setPositiveButton("Continue") { _, _ -> prefs.edit().putBoolean("onb", true).apply(); requestPerms() }.show()
    }
    private fun requestPerms() {
        val need = perms.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) permLauncher.launch(need.toTypedArray()) else afterPerms()
    }
    private fun afterPerms() { askRole(false) }

    fun askRole(force: Boolean): Boolean {
        val rm = getSystemService(RoleManager::class.java)
        if (!rm.isRoleAvailable(RoleManager.ROLE_SMS) || rm.isRoleHeld(RoleManager.ROLE_SMS)) return false
        if (!force && prefs.getBoolean("asked", false)) return false
        prefs.edit().putBoolean("asked", true).apply()
        roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_SMS))
        return true
    }

    fun showDiag() {
        val rm = getSystemService(RoleManager::class.java)
        val nmg = getSystemService(NotificationManager::class.java)
        val sb = StringBuilder()
        sb.append("Android ").append(Build.VERSION.SDK_INT).append(" · ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n')
        sb.append("Default SMS app: ").append(Telephony.Sms.getDefaultSmsPackage(this)).append('\n')
        sb.append("Role held: ").append(rm.isRoleHeld(RoleManager.ROLE_SMS)).append('\n')
        sb.append("Notifications: ").append(nmg.areNotificationsEnabled()).append('\n')
        perms.forEach { sb.append(it.substringAfterLast('.')).append(": ").append(checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED).append('\n') }
        sb.append("\nTrail:\n").append(CrashLog.trail(this)).append("\nLast crash:\n").append(CrashLog.last(this) ?: "none")
        val tv = android.widget.TextView(this).apply { text = sb; setTextIsSelectable(true); setPadding(40, 30, 40, 10); textSize = 12f }
        val sv = android.widget.ScrollView(this).apply { addView(tv) }
        AlertDialog.Builder(this).setTitle("Diagnostics").setView(sv)
            .setPositiveButton("Copy") { _, _ ->
                (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("aui", sb.toString()))
            }.setNegativeButton("Close", null).show()
    }

    fun openAppSettings() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }
}
