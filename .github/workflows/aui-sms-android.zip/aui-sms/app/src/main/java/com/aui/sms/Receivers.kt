package com.aui.sms

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Person
import android.app.RemoteInput
import android.app.Service
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Icon
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.BlockedNumberContract
import android.provider.ContactsContract
import android.provider.Telephony
import android.widget.Toast

object Notifier {
    const val CH = "messages"
    const val CH_SILENT = "info"
    private fun prefs(c: Context) = c.getSharedPreferences("sms-prefs", Context.MODE_PRIVATE)

    fun ensure(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Messages", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel(CH_SILENT, "Info", NotificationManager.IMPORTANCE_LOW))
    }

    fun nameOf(c: Context, addr: String): String {
        if (c.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return addr
        try {
            c.contentResolver.query(Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(addr)),
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) return it.getString(0) }
        } catch (e: Exception) {}
        return addr
    }

    fun cancel(c: Context, thread: String) { c.getSystemService(NotificationManager::class.java).cancel(thread, 1) }

    fun show(c: Context, thread: String, addr: String, body: String) {
        ensure(c)
        val pr = prefs(c)
        val name = nameOf(c, addr)
        val shown = if (pr.getBoolean("prev", true)) body else "New message"
        val code = if (pr.getBoolean("otp", true) && Regex("(?i)(code|otp|pin|password|verification|passcode|رمز|کد)").containsMatchIn(body))
            Regex("\\b\\d{4,8}\\b").find(body)?.value else null
        val tid = thread.hashCode()
        val mut = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
        val open = PendingIntent.getActivity(c, tid, Intent(c, MainActivity::class.java).putExtra("thread", thread)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val read = PendingIntent.getBroadcast(c, tid + 1, Intent(c, NotifActionReceiver::class.java).setAction(NotifActionReceiver.READ).putExtra("thread", thread),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val ri = RemoteInput.Builder("reply").setLabel("Reply").build()
        val replyPi = PendingIntent.getBroadcast(c, tid + 2, Intent(c, NotifActionReceiver::class.java).setAction(NotifActionReceiver.REPLY)
            .putExtra("thread", thread).putExtra("addr", addr), PendingIntent.FLAG_UPDATE_CURRENT or mut)
        val style = Notification.MessagingStyle(Person.Builder().setName("Me").build())
            .addMessage(shown, System.currentTimeMillis(), Person.Builder().setName(name).build())
        val b = Notification.Builder(c, CH).setSmallIcon(android.R.drawable.sym_action_chat).setContentTitle(name).setContentText(shown)
            .setStyle(style).setCategory(Notification.CATEGORY_MESSAGE).setAutoCancel(true).setContentIntent(open).setGroup("aui_sms")
            .setVisibility(Notification.VISIBILITY_PRIVATE)
            .addAction(Notification.Action.Builder(Icon.createWithResource(c, android.R.drawable.ic_menu_send), "Reply", replyPi).addRemoteInput(ri).build())
            .addAction(Notification.Action.Builder(Icon.createWithResource(c, android.R.drawable.ic_menu_agenda), "Mark read", read).build())
        if (code != null) {
            val cp = PendingIntent.getBroadcast(c, tid + 3, Intent(c, NotifActionReceiver::class.java).setAction(NotifActionReceiver.COPY)
                .putExtra("code", code).putExtra("thread", thread), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            b.addAction(Notification.Action.Builder(Icon.createWithResource(c, android.R.drawable.ic_menu_edit), "Copy $code", cp).build())
        }
        try { c.getSystemService(NotificationManager::class.java).notify(thread, 1, b.build()) } catch (e: Exception) { CrashLog.save(c, e) }
    }
}

/** Default-SMS-app entry point for incoming text messages. */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        try {
            val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
            if (msgs.isEmpty()) return
            val addr = msgs[0].originatingAddress ?: return
            val body = msgs.joinToString("") { it.messageBody ?: "" }
            val sub = i.getIntExtra("subscription", -1)
            val blocked = try { BlockedNumberContract.isBlocked(c, addr) } catch (e: Exception) { false }
            if (blocked) return
            val uri = SmsOps.insertInbox(c, addr, body, msgs[0].timestampMillis, sub)
            val thread = SmsOps.threadOf(c, uri)
            val clean = body.replace(Regex("\\s?\\[G:[a-z0-9]{3,8}]\\s*$"), "")
            if (body.contains("[AUI-G:")) {
                val gname = Regex("\\[AUI-G:[a-z0-9]{3,8}:([^:\\]]*):").find(body)?.groupValues?.get(1)?.let { try { Uri.decode(it) } catch (e: Exception) { it } } ?: ""
                Notifier.show(c, thread, addr, "Added you to group: $gname")
            } else Notifier.show(c, thread, addr, clean)
        } catch (e: Exception) { CrashLog.save(c, e) }
    }
}

/** MMS delivery is required for the default-SMS role; picture messages are not supported yet. */
class MmsReceiver : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) {} }

/** "Respond via message" (reject a call with a text) — required for the default-SMS role. */
class RespondViaMessageService : Service() {
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        try {
            val to = i?.data?.schemeSpecificPart?.substringBefore('?')
            val text = i?.getStringExtra(Intent.EXTRA_TEXT)
            if (!to.isNullOrEmpty() && !text.isNullOrEmpty()) SmsOps.send(this, to, text, -1)
        } catch (e: Exception) {}
        stopSelf(startId)
        return START_NOT_STICKY
    }
}

class NotifActionReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val thread = i.getStringExtra("thread") ?: return
        when (i.action) {
            READ -> SmsOps.markRead(c, thread)
            COPY -> {
                val code = i.getStringExtra("code") ?: return
                (c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("code", code))
                Toast.makeText(c, "Copied $code", Toast.LENGTH_SHORT).show()
                SmsOps.markRead(c, thread)
            }
            REPLY -> {
                val text = RemoteInput.getResultsFromIntent(i)?.getCharSequence("reply")?.toString()?.trim()
                val addr = i.getStringExtra("addr")
                if (!text.isNullOrEmpty() && !addr.isNullOrEmpty()) {
                    SmsOps.send(c, addr, text, c.getSharedPreferences("sms-prefs", Context.MODE_PRIVATE).getInt("lastSub", -1))
                    SmsOps.markRead(c, thread)
                }
            }
        }
    }
    companion object { const val READ = "com.aui.sms.READ"; const val REPLY = "com.aui.sms.REPLY"; const val COPY = "com.aui.sms.COPY" }
}
