package com.aui.sms

import android.app.Activity
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ContentResolver
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Telephony
import android.telephony.SmsManager
import org.json.JSONArray
import org.json.JSONObject

/** Everything that touches the SMS provider and SmsManager. */
@Suppress("DEPRECATION")
object SmsOps {
    val SMS: Uri = Telephony.Sms.CONTENT_URI
    private val TAG_RE = Regex("\\[G:[a-z0-9]{3,8}]\\s*$")
    fun isTagged(b: String) = b.contains("[AUI-G:") || TAG_RE.containsMatchIn(b)

    fun isDefault(c: Context) = Telephony.Sms.getDefaultSmsPackage(c) == c.packageName

    fun mgr(sub: Int): SmsManager =
        if (sub >= 0) SmsManager.getSmsManagerForSubscriptionId(sub) else SmsManager.getDefault()

    fun query(c: Context, uri: Uri, proj: Array<String>, sel: String?, args: Array<String>?, limit: Int, desc: Boolean = true): Cursor? {
        val b = Bundle().apply {
            if (sel != null) putString(ContentResolver.QUERY_ARG_SQL_SELECTION, sel)
            if (args != null) putStringArray(ContentResolver.QUERY_ARG_SQL_SELECTION_ARGS, args)
            putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, arrayOf("date"))
            putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION,
                if (desc) ContentResolver.QUERY_SORT_DIRECTION_DESCENDING else ContentResolver.QUERY_SORT_DIRECTION_ASCENDING)
            putInt(ContentResolver.QUERY_ARG_LIMIT, limit)
        }
        return try { c.contentResolver.query(uri, proj, b, null) } catch (e: Exception) { null }
    }

    fun kind(type: Int, status: Int): String = when (type) {
        Telephony.Sms.MESSAGE_TYPE_FAILED -> "failed"
        Telephony.Sms.MESSAGE_TYPE_OUTBOX, Telephony.Sms.MESSAGE_TYPE_QUEUED -> "queued"
        Telephony.Sms.MESSAGE_TYPE_SENT -> if (status == Telephony.Sms.STATUS_COMPLETE) "delivered" else "sent"
        else -> "recv"
    }

    // ---- reading ----
    fun conversations(c: Context, limit: Int): String {
        val proj = arrayOf("_id", "thread_id", "address", "body", "date", "type", "read", "sub_id")
        val map = LinkedHashMap<Long, JSONObject>()
        val unread = HashMap<Long, Int>()
        val cnt = HashMap<Long, Int>()
        query(c, SMS, proj, null, null, 5000)?.use { cur ->
            while (cur.moveToNext()) {
                val body = cur.getString(3) ?: ""
                if (isTagged(body)) continue
                val tid = cur.getLong(1)
                cnt[tid] = (cnt[tid] ?: 0) + 1
                if (cur.getInt(5) == 1 && cur.getInt(6) == 0) unread[tid] = (unread[tid] ?: 0) + 1
                if (!map.containsKey(tid)) map[tid] = JSONObject().put("id", tid).put("addr", cur.getString(2) ?: "")
                    .put("body", body).put("ts", cur.getLong(4)).put("type", cur.getInt(5)).put("sub", cur.getInt(7))
            }
        }
        val out = JSONArray()
        var n = 0
        for ((tid, o) in map) {
            out.put(o.put("unread", unread[tid] ?: 0).put("count", cnt[tid] ?: 0))
            if (++n >= limit) break
        }
        return out.toString()
    }

    private fun rows(cur: Cursor, skipTagged: Boolean): JSONArray {
        val list = ArrayList<JSONObject>()
        while (cur.moveToNext()) {
            val body = cur.getString(3) ?: ""
            if (skipTagged && isTagged(body)) continue
            list.add(JSONObject().put("id", cur.getLong(0)).put("addr", cur.getString(2) ?: "").put("body", body)
                .put("ts", cur.getLong(4)).put("type", cur.getInt(5)).put("read", cur.getInt(6))
                .put("sub", cur.getInt(7)).put("kind", kind(cur.getInt(5), cur.getInt(8))))
        }
        list.reverse()
        return JSONArray(list)
    }
    private val PROJ = arrayOf("_id", "thread_id", "address", "body", "date", "type", "read", "sub_id", "status")

    fun messages(c: Context, thread: String, limit: Int): String =
        query(c, SMS, PROJ, "thread_id=?", arrayOf(thread), limit)?.use { rows(it, true).toString() } ?: "[]"

    fun tagged(c: Context, tag: String, limit: Int): String =
        query(c, SMS, PROJ, "body LIKE ?", arrayOf("%$tag%"), limit)?.use { rows(it, false).toString() } ?: "[]"

    fun search(c: Context, q: String): String {
        val ids = LinkedHashSet<String>()
        query(c, SMS, arrayOf("_id", "thread_id", "address", "body", "date", "type", "read", "sub_id", "status"), "body LIKE ?", arrayOf("%$q%"), 300)?.use {
            while (it.moveToNext()) { if (!isTagged(it.getString(3) ?: "")) ids.add(it.getLong(1).toString()) }
        }
        return JSONArray(ids.toList()).toString()
    }

    // ---- writing ----
    fun markRead(c: Context, thread: String) {
        try {
            c.contentResolver.update(SMS, ContentValues().apply { put("read", 1); put("seen", 1) }, "thread_id=? AND read=0", arrayOf(thread))
        } catch (e: Exception) {}
        Notifier.cancel(c, thread)
    }
    fun deleteThread(c: Context, id: String) { try { c.contentResolver.delete(SMS, "thread_id=?", arrayOf(id)) } catch (e: Exception) {} }
    fun deleteMessage(c: Context, id: String) { try { c.contentResolver.delete(ContentUris.withAppendedId(SMS, id.toLong()), null, null) } catch (e: Exception) {} }

    fun insertInbox(c: Context, addr: String, body: String, sent: Long, sub: Int): Uri? = try {
        c.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, ContentValues().apply {
            put("address", addr); put("body", body); put("date", System.currentTimeMillis()); put("date_sent", sent)
            put("read", 0); put("seen", 0); put("type", Telephony.Sms.MESSAGE_TYPE_INBOX)
            if (sub >= 0) put("sub_id", sub)
        })
    } catch (e: Exception) { null }

    fun threadOf(c: Context, uri: Uri?): String {
        if (uri == null) return "0"
        return try { c.contentResolver.query(uri, arrayOf("thread_id"), null, null, null)?.use { if (it.moveToFirst()) it.getLong(0).toString() else "0" } ?: "0" } catch (e: Exception) { "0" }
    }

    private fun setType(c: Context, id: Long, type: Int, notFailed: Boolean) {
        if (id < 0) return
        try {
            c.contentResolver.update(ContentUris.withAppendedId(SMS, id), ContentValues().apply { put("type", type) },
                if (notFailed) "type!=?" else null, if (notFailed) arrayOf(Telephony.Sms.MESSAGE_TYPE_FAILED.toString()) else null)
        } catch (e: Exception) {}
    }
    fun markSent(c: Context, id: Long) = setType(c, id, Telephony.Sms.MESSAGE_TYPE_SENT, true)
    fun markFailed(c: Context, id: Long) = setType(c, id, Telephony.Sms.MESSAGE_TYPE_FAILED, false)
    fun markDelivered(c: Context, id: Long) {
        if (id < 0) return
        try { c.contentResolver.update(ContentUris.withAppendedId(SMS, id), ContentValues().apply { put("status", Telephony.Sms.STATUS_COMPLETE) }, null, null) } catch (e: Exception) {}
    }

    /** Sends one SMS. Returns the provider row id, or -1 when this app is not the default SMS app. */
    fun send(c: Context, addr: String, body: String, sub: Int): Long {
        var rowId = -1L
        if (isDefault(c)) {
            try {
                c.contentResolver.insert(SMS, ContentValues().apply {
                    put("address", addr); put("body", body); put("date", System.currentTimeMillis()); put("read", 1); put("seen", 1)
                    put("type", Telephony.Sms.MESSAGE_TYPE_QUEUED)
                    if (sub >= 0) put("sub_id", sub)
                })?.let { rowId = ContentUris.parseId(it) }
            } catch (e: Exception) {}
        }
        try {
            val sm = mgr(sub)
            val parts = sm.divideMessage(body)
            val sent = ArrayList<PendingIntent>()
            val deliv = ArrayList<PendingIntent>()
            val salt = (System.nanoTime() and 0xfffff).toInt() * 8
            for (i in parts.indices) {
                sent.add(PendingIntent.getBroadcast(c, salt + i, Intent(c, SentReceiver::class.java).setAction("com.aui.sms.SENT").putExtra("id", rowId),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
                deliv.add(PendingIntent.getBroadcast(c, salt + 4000000 + i, Intent(c, DeliveredReceiver::class.java).setAction("com.aui.sms.DELIVERED").putExtra("id", rowId),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            }
            if (parts.size > 1) sm.sendMultipartTextMessage(addr, null, parts, sent, deliv) else sm.sendTextMessage(addr, null, body, sent[0], deliv[0])
        } catch (e: Exception) { markFailed(c, rowId); CrashLog.save(c, e) }
        return rowId
    }
}

class SentReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getLongExtra("id", -1)
        if (resultCode == Activity.RESULT_OK) SmsOps.markSent(c, id) else SmsOps.markFailed(c, id)
    }
}

class DeliveredReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (resultCode == Activity.RESULT_OK) SmsOps.markDelivered(c, i.getLongExtra("id", -1))
    }
}

/** Scheduled messages: list lives in SharedPreferences, alarms fire ScheduleReceiver. */
object Scheduler {
    private fun p(c: Context) = c.getSharedPreferences("sms-sched", Context.MODE_PRIVATE)
    fun load(c: Context): JSONArray = try { JSONArray(p(c).getString("list", "[]")) } catch (e: Exception) { JSONArray() }
    fun raw(c: Context): String = p(c).getString("list", "[]") ?: "[]"
    fun save(c: Context, json: String) { p(c).edit().putString("list", json).apply(); scheduleAll(c) }

    private fun pi(c: Context, id: String, flags: Int) = PendingIntent.getBroadcast(c, id.hashCode(),
        Intent(c, ScheduleReceiver::class.java).setAction("com.aui.sms.SCHEDULE").putExtra("id", id), flags or PendingIntent.FLAG_IMMUTABLE)

    fun scheduleAll(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java)
        (p(c).getStringSet("ids", emptySet()) ?: emptySet()).forEach { id ->
            val old: PendingIntent? = pi(c, id, PendingIntent.FLAG_NO_CREATE)
            if (old != null) am.cancel(old)
        }
        val arr = load(c)
        val ids = HashSet<String>()
        val now = System.currentTimeMillis()
        val due = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val s = arr.getJSONObject(i)
            if (s.optString("st") != "pending") continue
            val id = s.optString("id"); val ts = s.optLong("ts")
            if (ts <= now) { due.add(id); continue }
            val op = pi(c, id, PendingIntent.FLAG_UPDATE_CURRENT)
            try {
                if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ts, op)
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ts, op)
                ids.add(id)
            } catch (e: Exception) { try { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ts, op); ids.add(id) } catch (e2: Exception) {} }
        }
        p(c).edit().putStringSet("ids", ids).apply()
        due.forEach { fire(c, it) }
    }

    private fun next(ts: Long, r: String): Long {
        val cal = java.util.Calendar.getInstance().apply { timeInMillis = ts }
        when (r) { "daily" -> cal.add(java.util.Calendar.DAY_OF_YEAR, 1); "weekly" -> cal.add(java.util.Calendar.DAY_OF_YEAR, 7); "monthly" -> cal.add(java.util.Calendar.MONTH, 1) }
        return cal.timeInMillis
    }

    fun fire(c: Context, id: String) {
        val arr = load(c)
        var changed = false
        for (i in 0 until arr.length()) {
            val s = arr.getJSONObject(i)
            if (s.optString("id") != id || s.optString("st") != "pending") continue
            val to = s.optJSONArray("to") ?: JSONArray()
            for (k in 0 until to.length()) SmsOps.send(c, to.getString(k), s.optString("body"), s.optInt("sub", -1))
            val rep = s.optString("repeat", "none")
            if (rep != "none") { var t = next(s.optLong("ts"), rep); while (t <= System.currentTimeMillis()) t = next(t, rep); s.put("ts", t) } else s.put("st", "sent")
            changed = true
        }
        if (changed) {
            p(c).edit().putString("list", arr.toString()).apply()
            val nm = c.getSystemService(android.app.NotificationManager::class.java)
            Notifier.ensure(c)
            nm.notify(("sch" + id).hashCode(), android.app.Notification.Builder(c, Notifier.CH_SILENT)
                .setSmallIcon(android.R.drawable.ic_menu_send).setContentTitle("Scheduled message sent").setAutoCancel(true).setTimeoutAfter(8000).build())
            scheduleAll(c)
        }
    }
}

class ScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getStringExtra("id") ?: return
        val pr = goAsync()
        Thread { try { Scheduler.fire(c, id) } finally { pr.finish() } }.start()
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { if (i.action == Intent.ACTION_BOOT_COMPLETED) Scheduler.scheduleAll(c) }
}
