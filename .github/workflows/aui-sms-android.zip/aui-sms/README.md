# AUI SMS (Android)

Offline SMS app: glass UI in `app/src/main/assets/index.html` (web) + Kotlin native layer
(SMS provider, SmsManager, notifications, alarms, speech). No INTERNET permission.

## Build
**GitHub (phone friendly):** upload `aui-sms-android.zip` + `.github/workflows/build.yml` (see chat) → Actions → download `aui-sms-debug`.
**Android Studio:** File → Open this folder → Run. **CLI:** `gradle assembleDebug` (Gradle 8.7, JDK 17, SDK 34).

## First run
Allow the permissions, then accept "Set as default SMS app" (needed to send/receive and to write messages).

## Notes
- Text SMS only. Picture messages (MMS) are not shown/sent yet.
- Groups: messages go to each member as normal SMS with a small `[G:id]` tag; other AUI SMS users see a group chat.
- Smart replies are rule-based and run fully on the device (English + Persian).
